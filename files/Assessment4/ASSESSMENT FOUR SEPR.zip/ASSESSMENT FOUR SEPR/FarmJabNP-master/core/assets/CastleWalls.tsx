<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.0" name="CastleWalls" tilewidth="64" tileheight="64" tilecount="6" columns="2">
 <image source="CastleWalls.png" width="128" height="192"/>
</tileset>
