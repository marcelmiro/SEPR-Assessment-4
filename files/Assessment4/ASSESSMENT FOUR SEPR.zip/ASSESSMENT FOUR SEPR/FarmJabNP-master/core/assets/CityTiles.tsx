<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.0" name="CityTiles" tilewidth="16" tileheight="16" spacing="1" tilecount="486" columns="27">
 <image source="tilemap.png" width="458" height="305"/>
</tileset>
